# Milan Mesh — Offline Chat Prototype

यह Android prototype Google Nearby Connections का उपयोग करता है। Nearby Connections Bluetooth/BLE और Wi‑Fi आधारित peer-to-peer connection से इंटरनेट के बिना devices के बीच data exchange कर सकता है। Cluster strategy mesh-जैसी multi-device topology के लिए उपयुक्त है।

## अभी क्या काम करता है
- Nearby device discovery
- बिना SIM/मोबाइल डेटा के text message transfer
- एक device से कई connected devices
- TTL आधारित basic message relay (mesh-style forwarding)
- Android runtime permissions

## जरूरी सीमा
- दोनों फोन में Milan Mesh installed होना चाहिए।
- फोन रेडियो range में होने चाहिए; multi-hop के लिए बीच के फोन भी Milan Mesh network में connected होने चाहिए।
- यह prototype production-grade end-to-end encryption, background service, photo/file transfer, voice, spam protection और polished UI अभी नहीं देता।
- कुछ Android devices पर Google Play services/Nearby support और system permissions जरूरी हो सकते हैं।

## Android Studio में खोलना
1. Android Studio खोलें।
2. इस पूरे `MilanMesh` folder को Open करें।
3. Gradle sync होने दें।
4. दो Android phones में USB debugging चालू करके app install करें।
5. दोनों में permissions Allow करें और **Offline Network शुरू करें** दबाएँ।
6. दोनों phones को पास रखें और message भेजकर test करें।

## Dependency
`com.google.android.gms:play-services-nearby:19.5.1`

## अगला version
- PIN/QR based pairing
- वास्तविक E2E encryption
- background mesh service
- photo/file transfer
- voice messages
- contacts/profile
- delivery/read status
- battery optimization
- production UI
