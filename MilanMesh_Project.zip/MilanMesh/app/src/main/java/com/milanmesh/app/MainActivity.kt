package com.milanmesh.app

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.nio.charset.StandardCharsets
import java.util.UUID

class MainActivity : Activity() {
    private val serviceId = "com.milanmesh.app"
    private val strategy = Strategy.P2P_CLUSTER
    private val connections by lazy { Nearby.getConnectionsClient(this) }
    private val endpoints = linkedMapOf<String, String>()
    private val connected = linkedSetOf<String>()
    private val seen = mutableSetOf<String>()
    private val deviceNames = mutableListOf<String>()
    private lateinit var devices: ListView
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var startButton: Button
    private lateinit var message: EditText
    private lateinit var sendButton: Button
    private lateinit var adapter: ArrayAdapter<String>
    private val permissions = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status); chat = findViewById(R.id.chat); devices = findViewById(R.id.devices)
        startButton = findViewById(R.id.startButton); message = findViewById(R.id.message); sendButton = findViewById(R.id.sendButton)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, deviceNames); devices.adapter = adapter
        startButton.setOnClickListener { ensurePermissionsAndStart() }
        sendButton.setOnClickListener { sendChat() }
        devices.setOnItemClickListener { _, _, position, _ -> endpoints.entries.elementAtOrNull(position)?.key?.let { requestConnection(it) } }
        buildPermissionList()
    }

    private fun buildPermissionList() {
        if (Build.VERSION.SDK_INT >= 31) permissions += listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
        else permissions += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.NEARBY_WIFI_DEVICES
    }

    private fun ensurePermissionsAndStart() {
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 42) else startNetwork()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startNetwork()
        else status.text = "Permissions जरूरी हैं। फिर से Start दबाएँ।"
    }

    private fun startNetwork() {
        status.text = "📡 खोज रहा हूँ… SIM/Internet की जरूरत नहीं"
        val adv = AdvertisingOptions.Builder().setStrategy(strategy).build()
        connections.startAdvertising(localName(), serviceId, lifecycle, adv)
            .addOnFailureListener { status.text = "Advertising error: ${it.message}" }
        val disc = DiscoveryOptions.Builder().setStrategy(strategy).build()
        connections.startDiscovery(serviceId, discovery, disc)
            .addOnFailureListener { status.text = "Discovery error: ${it.message}" }
        startButton.text = "🟢 Offline Network चालू है"
    }

    private fun localName(): String = "Milan-${android.os.Build.MODEL.take(12)}"

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            runOnUiThread {
                endpoints[endpointId] = info.endpointName
                refreshDevices()
                status.text = "Nearby device मिला: ${info.endpointName}"
            }
            requestConnection(endpointId)
        }
        override fun onEndpointLost(endpointId: String) { runOnUiThread { endpoints.remove(endpointId); refreshDevices() } }
    }

    private fun refreshDevices() {
        deviceNames.clear(); deviceNames += endpoints.values.map { "📱 $it" }; adapter.notifyDataSetChanged()
    }

    private fun requestConnection(endpointId: String) {
        connections.requestConnection(localName(), endpointId, lifecycle)
            .addOnFailureListener { runOnUiThread { status.text = "Connection request failed" } }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            // Prototype: automatically accept after showing the authentication code in status.
            connections.acceptConnection(endpointId, payloadCallback)
            runOnUiThread { status.text = "🔗 Connecting: ${info.endpointName} | Code: ${info.authenticationDigits}" }
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            runOnUiThread {
                if (result.status.isSuccess) { connected += endpointId; status.text = "🟢 Connected: ${endpoints[endpointId] ?: endpointId}" }
                else status.text = "Connection failed: ${result.status.statusMessage}"
            }
        }
        override fun onDisconnected(endpointId: String) { connected.remove(endpointId); runOnUiThread { status.text = "Device disconnected" } }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val raw = payload.asBytes()?.toString(StandardCharsets.UTF_8) ?: return
            val parts = raw.split("|", limit = 4); if (parts.size < 4 || parts[0] != "MM1") return
            val id = parts[1]; val ttl = parts[2].toIntOrNull() ?: 0; val text = String(Base64.decode(parts[3], Base64.NO_WRAP), StandardCharsets.UTF_8)
            if (!seen.add(id)) return
            runOnUiThread { chat.append("\n${endpoints[endpointId] ?: "Nearby"}: $text") }
            if (ttl > 0) forward(id, ttl - 1, text, except = endpointId)
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private fun sendChat() {
        val text = message.text.toString().trim(); if (text.isEmpty() || connected.isEmpty()) return
        val id = UUID.randomUUID().toString(); seen += id
        sendEnvelope(id, 3, text, connected.toList()); chat.append("\nमैं: $text"); message.text.clear()
    }

    private fun forward(id: String, ttl: Int, text: String, except: String) {
        val targets = connected.filter { it != except }; if (targets.isNotEmpty()) sendEnvelope(id, ttl, text, targets)
    }

    private fun sendEnvelope(id: String, ttl: Int, text: String, targets: List<String>) {
        val encoded = Base64.encodeToString(text.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
        val bytes = "MM1|$id|$ttl|$encoded".toByteArray(StandardCharsets.UTF_8)
        targets.forEach { connections.sendPayload(it, Payload.fromBytes(bytes)) }
    }

    override fun onDestroy() { connections.stopAdvertising(); connections.stopDiscovery(); connections.stopAllEndpoints(); super.onDestroy() }
}
